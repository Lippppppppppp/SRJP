clear;
seed = 12345678;
rand('seed', seed);
load('../data/disease_sim_2017.mat');
load('../data/lncR_disease_2017.mat');
load('../data/lncR_sim_2017.mat');
lncSim = lncR_sim_matrix;
disSim_Jaccard = disease_sim_matrix;
interMatrix = lncR_disease_matrix;
y = interMatrix;
Iteration=5;

K1 = [];
mat = process_kernel(lncSim);
K1(:,:,1)=Knormalized(mat);
K2 = [];
mat = process_kernel(disSim_Jaccard);
K2(:,:,1)=Knormalized(mat);

nfolds =5; nruns=1;
d1 = 30;d2 = 120;
lambda1 = 2^2;
lambda2 = 2^5;
lambda3 = 2^-1;
alpha1 = 2^5;
crossval_idx = crossvalind('Kfold',y(:),nfolds);
results = [];

% for d1 =[10,30,60,90,120,150,180]
%     for d2 =[10,20,40,60,80,100,120]
        
fold_auc=[];fold_aupr=[];RMSE=[];

for fold = 1:nfolds
    y_train = interMatrix;
	test_idx  = find(crossval_idx==fold);
	y_train(test_idx) = 0;
	%K1(:,:,2)=kernel_corr(y_train,1,0,1);
	%K2(:,:,2)=kernel_corr(y_train,2,0,1);
	[KD, KL] = GaussianKernel(y_train', 1, 1);
	K1(:,:,2)=KL;
	K2(:,:,2)=KD;
	[KD, KL] = consine(y_train');
	K1(:,:,3)=KL;
	K2(:,:,3)=KD;
	
	[weight_v1] = [1/3,1/3,1/3];
	K_COM1 = combine_kernels(weight_v1, K1);
	
    [weight_v2] = [1/3,1/3,1/3];
	K_COM2 = combine_kernels(weight_v2, K2);
	
	%3.SRJP
    [F_1] =SRJP(K_COM1,K_COM2,y_train,lambda1,lambda2,lambda3,alpha1,d1,d2,Iteration);

    test_labels = y(test_idx);
    predict_scores = F_1(test_idx);
    [X_1,Y_1,tpr,aupr_F_1] = perfcurve(test_labels,predict_scores,1, 'xCrit', 'reca', 'yCrit', 'prec');
    [X,Y,THRE,AUC_F_1,OPTROCPT,SUBY,SUBYNAMES] = perfcurve(test_labels,predict_scores,1);
    fprintf('---------------- FOLD %d  \n',  fold)
    fprintf('--- FOLD %d - DHRLS---AUPR: %f ---AUC: %f \n', fold,aupr_F_1, AUC_F_1)

    fold_aupr=[fold_aupr;aupr_F_1];
    fold_auc=[fold_auc;AUC_F_1];
    RMSE = [RMSE; sqrt(sum((predict_scores-test_labels).^2)/length(predict_scores))];
end
        mean_aupr = mean(fold_aupr)
        mean_auc = mean(fold_auc)
        mean_RMSE = mean(RMSE)

%     end
% end

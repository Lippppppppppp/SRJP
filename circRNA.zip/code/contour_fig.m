clc,clear
load ./results/D1_result1.txt
data = D1_result1;

AUPR = data(:,4);
AUC = data(:,3);
X_range = data(:,1);
Y_range = data(:,2);
results_AUPR = [X_range,Y_range,AUPR];
results_AUC = [X_range,Y_range,AUC];
param1 = [100,200,300,400,500];
param2 = [10,20,40,60,80];
%contour_Fig(param1,param2,results_AUC)
contour_Fig(param1,param2,results_AUPR)

function contour_Fig(param1,param2,results)
    [X,Y] = meshgrid(param1,param2);
    matrix_ROC = zeros(length(param1));
    for i = 1:length(param2)
        for j = 1:length(param1)
            matrix_ROC(i,j) = results(find(results(:,1)==X(i,j) & results(:,2)==Y(i,j)),3); 
        end
    end
    contourf(X,Y,matrix_ROC,2000,'LineStyle','none');
    xlabel('Parameter of d_1');
    ylabel('Parameter of d_2');
    set(gca,'xtick',param1);
    set(gca,'ytick',param2);
end
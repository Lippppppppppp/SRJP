clear;
%seed = 12345678;
%rand('seed', seed);
nfolds = 5; nruns=1;
CVS=1; Iteration=5;
dataname = '';
dataname
% load adjacency matrix
[y,L1,L2] = loadtabfile(['../data/interactions/' dataname 'cd_adjmat.txt']);
d1 = 200;d2 = 80;
lambda1 = 2^-4;
lambda2 = 2^4;
lambda3 = 2^-2;
alpha1 = 2^1;
results = [];

for run=1:nruns
    % split folds
	[num_D,num_G] = size(y);
	if CVS == 1
		crossval_idx = crossvalind('Kfold',y(:),nfolds);
	elseif CVS == 2
		KP = 1:1:num_D;
		crossval_idx = crossvalind('Kfold',KP,nfolds);
	elseif CVS == 3
		KP = 1:1:num_G;
		crossval_idx = crossvalind('Kfold',KP,nfolds);
    end
    
%     for d1 =[100,200,300,400,500]
%         for d2 =[10,20,40,60,80]
%         
            fold_aupr=[];fold_auc=[]; RMSE=[];
        
        for fold=1:nfolds
            
        train_idx = find(crossval_idx~=fold);
        test_idx  = find(crossval_idx==fold);
        y_train = y;
        
		if CVS == 1
			y_train(test_idx) = 0;
        elseif CVS == 2
			y_train(test_idx,:) = 0;
        elseif CVS == 3
			y_train(:,test_idx) = 0;
		end
		
        %%  1.kernels
		%% cal kernels
        k1_paths = {['../data/interactions/' dataname 'circRNA_Gene.txt'],...
					['../data/interactions/' dataname 'circRNA_miRNA.txt'],...
                    };
		K1 = [];
        for i=1:length(k1_paths)
            [y_,l1,l2] = loadtabfile(k1_paths{i});
			K1(:,:,i) = kernel_corr(y_,1,0,1);
        end
		k2_paths = {['../data/kernels/' dataname 'circSim.txt']
                   };
        for j=1:length(k2_paths)
            i = i+1;
            [mat, labels] = loadtabfile(k2_paths{j});
            mat = process_kernel(mat);
            K1(:,:,i) = Knormalized(mat);
        end
        K1(:,:,i+1) = kernel_corr(y_train,1,0,1);
		
		%K1 compelted
		
        k3_paths = {['../data/interactions/' dataname 'disease_Gene.txt'],...
                   
                    ['../data/interactions/' dataname 'disease_miRNA.txt'],...
                    };
        K2 = [];
        for i=1:length(k3_paths)
            [y_,l1,l2] = loadtabfile(k3_paths{i});
			K2(:,:,i) = kernel_corr(y_,1,0,1);
        end
        k4_paths = {['../data/kernels/' dataname 'disease_sim.txt']
                   };
        for k=1:length(k4_paths)
            i=i+1;
            [mat, labels] = loadtabfile(k4_paths{k});
            mat = process_kernel(mat);
            K2(:,:,i) = Knormalized(mat);
        end
        K2(:,:,i+1) = kernel_corr(y_train,2,0,1);
		
		%K1 compelted
		
		[weight_v1] = [0.25,0.25,0.25,0.25];
		K_COM1 = combine_kernels(weight_v1, K1);
		
		[weight_v2] = [0.25,0.25,0.25,0.25];
		K_COM2 = combine_kernels(weight_v2, K2);
        
		%3.SRJP
        [A_cos_com] = SRJP(K_COM1,K_COM2,y_train,lambda1,lambda2,lambda3,alpha1,d1,d2,Iteration);
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
        %% 4. evaluate predictions
        yy=y;
    
		if CVS == 1
			test_labels = yy(test_idx);
			predict_scores = A_cos_com(test_idx);
		elseif CVS == 2
			test_labels1 = yy(test_idx,:);
			test_labels = test_labels1(:);
			predict_scores = A_cos_com(test_idx,:);
			predict_scores = predict_scores(:);
		elseif CVS == 3
			test_labels1 = yy(:,test_idx);
			test_labels = test_labels1(:);
			predict_scores = A_cos_com(:,test_idx);
			predict_scores = predict_scores(:);
		end
		[X,Y,tpr,aupr_] = perfcurve(test_labels,predict_scores,1, 'xCrit', 'reca', 'yCrit', 'prec');		
		[X,Y,THRE,AUC_,OPTROCPT,SUBY,SUBYNAMES] = perfcurve(test_labels,predict_scores,1);	
		fprintf('---------------\nRUN %d - FOLD %d  \n', run, fold)
		fprintf('%d - FOLD %d - weighted_kernels_: %f \n', run, fold, aupr_)
		
		fold_aupr=[fold_aupr;aupr_];%逗号行，分号列
		fold_auc=[fold_auc;AUC_];
        RMSE = [RMSE; sqrt(sum((predict_scores-test_labels).^2)/length(predict_scores))];
        end 
        mean_aupr = mean(fold_aupr)
        mean_auc = mean(fold_auc)
        mean_RMSE = mean(RMSE)
        
%     end
%     end
end



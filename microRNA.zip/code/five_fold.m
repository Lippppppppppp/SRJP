clear;
seed = 12345678;
rand('seed', seed);
load('../data/dataset.mat');
y = miRNA_disease_Y;

K1 = [];
K1(:,:,1)=miRNA_Function_S;
K1(:,:,2)=miRNA_Sequences_Needle_S;
K2 = [];
K2(:,:,1)=disease_Function_S;
K2(:,:,2)=disease_Sem_S;

nfolds = 5; nruns=1;Iteration=5;
d1 = 200;d2 =300;
lambda1 = 1;
lambda2 = 32;
lambda3 = 2^-1;
alpha1 = 2^-5;
crossval_idx = crossvalind('Kfold',y(:),nfolds);
results = [];


% for d1 = [50,100,200,300,400,490]
%     for d2 =[50,100,150,200,250,300]    
    fold_auc=[];fold_aupr=[];RMSE=[];
        
for fold = 1:nfolds
   
    y_train = miRNA_disease_Y;
	test_idx  = find(crossval_idx==fold);
	y_train(test_idx) = 0;
	K1(:,:,3)=kernel_corr(y_train,1,0,1);
	K2(:,:,3)=kernel_corr(y_train,2,0,1);
	
	K_COM1=combine_kernels([1/3,1/3,1/3],K1);
	K_COM2=combine_kernels([1/3,1/3,1/3],K2);
	
	%3.SRJP
    [F_1] = SRJP(K_COM1,K_COM2,y_train,lambda1,lambda2,lambda3,alpha1,d1,d2,Iteration);

    test_labels = y(test_idx);
    predict_scores = F_1(test_idx);
    [X_1,Y_1,tpr,aupr_F_1] = perfcurve(test_labels,predict_scores,1, 'xCrit', 'reca', 'yCrit', 'prec');
    [X,Y,THRE,AUC_F_1,OPTROCPT,SUBY,SUBYNAMES] = perfcurve(test_labels,predict_scores,1);
    fprintf('---------------- FOLD %d  \n',  fold)
    fprintf('--- FOLD %d - DHRLS---AUPR: %f ---AUC: %f \n', fold,aupr_F_1, AUC_F_1)

    fold_aupr=[fold_aupr;aupr_F_1];
    fold_auc=[fold_auc;AUC_F_1]; 
    RMSE = [RMSE; sqrt(sum((predict_scores-test_labels).^2)/length(predict_scores))];
end

        mean_aupr = mean(fold_aupr)
        mean_auc = mean(fold_auc)
        mean_RMSE = mean(RMSE)
        
%     end
% end

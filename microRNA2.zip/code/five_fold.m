clear;
seed = 12345678;
rand('seed', seed);
%% %liping's methods
% load('../data/dataset.mat');
% y = miRNA_disease_Y;
% 
% K1 = [];
% K1(:,:,1)=miRNA_Function_S;
% K1(:,:,2)=miRNA_Sequences_Needle_S;
% K2 = [];
% K2(:,:,1)=disease_Function_S;
% K2(:,:,2)=disease_Sem_S;

%% GATMDA
% disease_lncRNA_matrix = load('../data/GATMDA/lncdis.csv')';
% miRNA_lncRNA_matrix = load('../data/GATMDA/milnc.csv');
% 
% miRNA_sim_matrix= load('../data/GATMDA/miRNA-miRNA.csv');
% disease_sim_matrix = load('../data/GATMDA/disease-disease.csv');
% 
% miRNA_disease_Y = load('../data/GATMDA/midis.csv');
% y = miRNA_disease_Y;
% 
% % process K1 kernel
% K1 = [];
% K1(:,:,1) = kernel_corr(miRNA_lncRNA_matrix,1,0,1);
% K1(:,:,2) = (process_kernel(miRNA_sim_matrix));
% 
% % process K2 kernel
% K2 = [];
% K2(:,:,1) = kernel_corr(disease_lncRNA_matrix,1,0,1);
% K2(:,:,2) = (process_kernel(disease_sim_matrix));

%% % MDA
% disease_GIP = load('../data/MDA-GCNFTG/D_GSM.txt');
% disease_sem1 = load('../data/MDA-GCNFTG/D_SSM1.txt');
% disease_sem2 = load('../data/MDA-GCNFTG/D_SSM2.txt');
% RNA_f = load('../data/MDA-GCNFTG/M_FSM.txt');
% RNA_GIP = load('../data/MDA-GCNFTG/M_GSM.txt');
% miRNA_disease_Y = load('../data/MDA-GCNFTG/all_mirna_disease.mat').Y;
% y = miRNA_disease_Y;

% % process K1 kernel
% K1 = [];
% K1(:,:,1) = RNA_f;
% K1(:,:,2) = RNA_GIP;
% 
% K2 = [];
% K2(:,:,1) = (disease_sem1+disease_sem2)/2;
% K2(:,:,2) = disease_GIP;

%% MMGCN
disease_target_sim = load('../data/MMGCN/d_d_f.csv');
disease_sem_sim = load('../data/MMGCN/d_d_s.csv');
miRNA_disease_Y = load('../data/MMGCN/m_d.csv');
mRNA_f_sim = load('../data/MMGCN/m_m_f.csv');
mRNA_seq_sim = load('../data/MMGCN/m_m_s.csv');
y = miRNA_disease_Y;

K1 = [];
K1(:,:,1) = mRNA_f_sim;
K1(:,:,2) = mRNA_seq_sim;

K2 = [];
K2(:,:,1) = disease_target_sim;
K2(:,:,2) = disease_sem_sim;


%% running
nfolds = 5; nruns=1;Iteration=5;
d1 = 50;d2 =500;
%d1 = 100;d2 =400;
lambda1 = 32;
lambda2 = 8;
lambda3 = 2;
alpha1 = 4;
crossval_idx = crossvalind('Kfold',y(:),nfolds);
results = [];


%  for d1 = [50,100]
%      for d2 =[100,200,300,400,500,590]
%           for Iteration = [1,5,10,50,100]        
%               for alpha1 = [2^-5,2^-4,2^-3,2^-2,2^-1,2^0,2^1,2^2,2^3,2^4,2^5] 
    
    runs_aupr=[];runs_auc=[];runs_RMSE=[];
for runs =1:nruns
    fold_auc=[];fold_aupr=[];RMSE=[];
for fold = 1:nfolds
   
    y_train = miRNA_disease_Y;
	test_idx  = find(crossval_idx==fold);
	y_train(test_idx) = 0;
% 	K1(:,:,3)=kernel_corr(y_train,1,0,1);
% 	K2(:,:,3)=kernel_corr(y_train,2,0,1);
	
% 	K_COM1=combine_kernels([1/3,1/3,1/3],K1);
% 	K_COM2=combine_kernels([1/3,1/3,1/3],K2);
	
% MMGCN
	K_COM1=combine_kernels([1/2,1/2],K1);
	K_COM2=combine_kernels([1/2,1/2],K2);

	%3.SRJP
    [F_1] = SRJP(K_COM1,K_COM2,y_train,lambda1,lambda2,lambda3,alpha1,d1,d2,Iteration);

    test_labels = y(test_idx);
    predict_scores = F_1(test_idx);
    [X_1,Y_1,tpr,aupr_F_1] = perfcurve(test_labels,predict_scores,1, 'xCrit', 'reca', 'yCrit', 'prec');
    [X,Y,THRE,AUC_F_1,OPTROCPT,SUBY,SUBYNAMES] = perfcurve(test_labels,predict_scores,1);
    fprintf('---------------- FOLD %d  \n',  fold)
    fprintf('--- FOLD %d - DHRLS---AUPR: %f ---AUC: %f \n', fold,aupr_F_1, AUC_F_1)

    fold_aupr=[fold_aupr;aupr_F_1];
    fold_auc=[fold_auc;AUC_F_1]; 
    RMSE = [RMSE; sqrt(sum((predict_scores-test_labels).^2)/length(predict_scores))];
end

        mean_aupr = mean(fold_aupr)
        mean_auc = mean(fold_auc)
        mean_RMSE = mean(RMSE)
        
        runs_aupr=[runs_aupr;mean_aupr];
        runs_auc=[runs_auc;mean_auc];
        runs_RMSE=[runs_RMSE;mean_RMSE];
end
runs_mean_aupr = mean(runs_aupr)
runs_mean_auc = mean(runs_auc)
runs_mean_RMSE = mean(runs_RMSE)

%          results = cat(1,results,[Iteration,mean_auc,mean_aupr,mean_RMSE]);
%          results = cat(1,results,[d1,d2,mean_auc,mean_aupr,mean_RMSE]);
%          save_results(['./results/MMGCN_did22.txt'],results);
%      end
%  end

function [LapA] = SRJP(S1,S2,y,lamda1,lamda2,lamda3,alpha,d1,d2,Iteration)
LapA=[];
[n,m] = size(y);
seed = 12345678;
rand('seed', seed);
P = rand(d1,d2);
W1 = rand(d1,m);
W2 = rand(d2,n);

%S1=preprocess_PNN(W1,p_nearest_neighbor);
%S2=preprocess_PNN(W2,p_nearest_neighbor);
L_H1=[];
L_H2=[];

% S_1 =preprocess_PNN(S1,k_nn);
S_1 = S1;
d_1 = sum(S_1);   %returning a row vector of the sums of each column.
D_1 = diag(d_1);
L_D_1 = D_1 - S_1;
d_tmep_1=eye(n)/(D_1^(1/2));
L_H1 = d_tmep_1*L_D_1*d_tmep_1;
	
% S_2 =preprocess_PNN(S2,k_nn);
S_2 = S2;
d_2 = sum(S_2);
D_2 = diag(d_2);
L_D_2 = D_2 - S_2;
d_tmep_2=eye(m)/(D_2^(1/2));
L_H2 = d_tmep_2*L_D_2*d_tmep_2;


[U1,S_k1,V1] = svds(S1,d1);
A = U1*(S_k1^0.5);  

[U2,S_k2,V2] = svds(S2,d2);
B = U2*(S_k2^0.5); 

[U,S,V]=svd(P);
U3=U;
V3=V;

E=eye(d2,d1); 
Z1=pinv(diag(sqrt(sum(W1.^2,2))));
Z2=pinv(diag(sqrt(sum(W2.^2,2))));

inv_A = pinv(A);
t_inv_B = pinv(B');
ki = eye(n);
%A = W1;
%B = W2;
for i=1:Iteration
	W1 = 2*pinv(2*A'*A+2*alpha*A'*L_H1*A+lamda1*Z1)*A'*y;
    W2 = 2*pinv(2*B'*B+2*alpha*B'*L_H2*B+lamda2*Z2)*B'*y';
	P=inv_A*y*t_inv_B-0.5*lamda3*pinv(A'*A)*U3*E'*V3'*pinv(B'*B);
    [U,S,V]=svd(P);
    U3=U;
    V3=V;
    Z1=pinv(diag(sqrt(sum(W1.^2,2))));
    Z2=pinv(diag(sqrt(sum(W2.^2,2))));
end	
	%reconstruct Y*
  
%LapA = A*W1;
%LapA =(B*W2)';
%LapA = A*P*B';
%LapA =(A*W1+ (B*W2)')/2;
%LapA =(A*W1+A*P*B')/2;
%LapA =((B*W2)'+A*P*B')/2;
LapA =(A*W1 + (B*W2)' +A*P*B')/3;

end


function S=preprocess_PNN(S,p)
%preprocess_PNN sparsifies the similarity matrix S by keeping, for each
%drug/target, the p nearest neighbors and discarding the rest.
%
% S = preprocess_PNN(S,p)

    NN_mat = zeros(size(S));

    % for each drug/target...
    for j=1:length(NN_mat)
        row = S(j,:);                           % get row corresponding to current drug/target
        row(j) = 0;                             % ignore self-similarity
        [~,indx] = sort(row,'descend');         % sort similarities descendingly
        indx = indx(1:p);                       % keep p NNs
        NN_mat(j,indx) = S(j,indx);             % keep similarities to p NNs
        NN_mat(j,j) = S(j,j);                   % also keep the self-similarity (typically 1)
    end

    % symmetrize the modified similarity matrix
    S = (NN_mat+NN_mat')/2;

end